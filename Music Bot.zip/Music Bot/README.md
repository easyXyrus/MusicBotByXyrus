# Music Bot

A feature-rich Discord music bot powered by **Discord.js v14**, **Lavalink**, and **Kazagumo**.

## Setup

1. **Fill in your `.env` file:**
   ```
   DISCORD_TOKEN=your_discord_bot_token
   LAVALINK_HOST=localhost
   LAVALINK_PORT=2333
   LAVALINK_PASSWORD=youshallnotpass
   LAVALINK_SECURE=false
   ```

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Start a Lavalink server** (Java 17+ required):
   - Download from: https://github.com/lavalink-devs/Lavalink/releases

4. **Start the bot:**
   ```
   npm start
   ```

## Commands

| Command | Description |
|---|---|
| `!play <song>` | Play a song or playlist |
| `!pause` | Pause playback |
| `!resume` | Resume playback |
| `!stop` | Stop and clear queue |
| `!skip` | Skip current song |
| `!queue [page]` | View the queue |
| `!nowplaying` | Show current track + progress bar |
| `!volume <0-100>` | Set volume |
| `!loop <off/track/queue>` | Set loop mode |
| `!shuffle` | Shuffle the queue |
| `!help` | Show all commands |
