const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MessageFlags,
} = require('discord.js');
const db247 = require('../../utils/db247');

module.exports = {
    name: '24/7',
    aliases: ['247'],
    category: 'admin',
    description: 'Toggle 24/7 mode (prevents bot from leaving when queue is empty)',
    cooldown: 5,

    async execute(message, args, client) {

        // ── Permission check: needs Manage Guild ───────────────────────────────
        if (
            !message.member.permissions.has('ManageGuild') &&
            message.author.id !== '1490225874585518150'
        ) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF4444)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🚫 Missing Permission\n> You need **Manage Server** permission to toggle 24/7 mode.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const sub = args[0]?.toLowerCase();
        const isCurrentlyEnabled = db247.isEnabled(message.guild.id);

        // ── Status view if no args ─────────────────────────────────────────────
        if (!sub) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🕒 24/7 Mode`
                            )
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**Status** — ${isCurrentlyEnabled ? '<:wavieo_tick:1512706892713955372> `Enabled`' : '<:wavieo_cross:1512706979502755980> `Disabled`'}\n\n` +
                                `To enable:  \`24/7 enable\`\n` +
                                `To disable: \`24/7 disable\``
                            )
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `-# When enabled, the bot will not disconnect when the queue ends.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ── Enable ─────────────────────────────────────────────────────────────
        if (sub === 'enable' || sub === 'on') {
            if (isCurrentlyEnabled) return message.reply('<:wavieo_tick:1512706892713955372> 24/7 mode is already enabled.');
            
            db247.enable(message.guild.id);

            // Cancel any pending disconnect timeout if the bot is currently in a channel
            const player = client.lavalink.getPlayer(message.guild.id);
            if (player && player.emptyTimeout) {
                clearTimeout(player.emptyTimeout);
                player.emptyTimeout = null;
            }

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`## <:wavieo_tick:1512706892713955372> 24/7 Enabled\n> I will now stay in the voice channel 24/7!`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ── Disable ────────────────────────────────────────────────────────────
        if (sub === 'disable' || sub === 'off') {
            if (!isCurrentlyEnabled) return message.reply('<:wavieo_cross:1512706979502755980> 24/7 mode is already disabled.');
            
            db247.disable(message.guild.id);

            // Start disconnect timeout if queue is empty
            const player = client.lavalink.getPlayer(message.guild.id);
            if (player && !player.queue.current) {
                player.emptyTimeout = setTimeout(() => {
                    if (!player.queue.current) {
                        player.destroy();
                        const channel = client.channels.cache.get(player.textChannelId);
                        if (channel) channel.send('👋 Disconnected due to inactivity.').catch(() => {});
                    }
                }, 30000);
            }

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`## <:wavieo_cross:1512706979502755980> 24/7 Disabled\n> I will now automatically leave when the queue is empty.`)
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        return message.reply('<:wavieo_cross:1512706979502755980> Invalid argument. Use `enable` or `disable`.');
    },
};
