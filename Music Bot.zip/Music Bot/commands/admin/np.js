const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require('discord.js');
const db = require('../../utils/npDB');
const { createContainer } = require('../../utils/containerUI');

const OWNER_ID = '1490225874585518150';

module.exports = {
    name: 'np',
    category: 'admin',
    description: 'Manage no-prefix users (Owner only)',

    async execute(message, args, client) {

        // ── Owner only ─────────────────────────────────────────────────────────
        if (message.author.id !== OWNER_ID) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF4444)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🚫 Access Denied\n> This command is restricted to the **bot owner** only.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const sub = args[0]?.toLowerCase();

        // ──────────────────────────────────────────────────────────────────────
        // np add <user|id> <duration>
        // ──────────────────────────────────────────────────────────────────────
        if (sub === 'add') {
            const target = await resolveUser(message, args[1], client);
            if (!target) return message.reply(createContainer('<:wavieo_cross:1512706979502755980> User not found. Use a mention or valid user ID.', 0xFF4444));

            const durationStr = args[2];
            let durationMs = null;

            if (durationStr) {
                durationMs = db.parseDuration(durationStr);
                if (durationMs === null)
                    return message.reply(createContainer('<:wavieo_cross:1512706979502755980> Invalid duration. Examples: `30m`, `2h`, `7d`', 0xFF4444));
            }

            const entry = db.addUser(target.id, target.tag || target.username, message.author.tag, durationMs);

            // DM the user
            target.send(createContainer(`🎉 **Good news!** You have been granted **No-Prefix** access in the bot.\nDuration: \`${entry.durationLabel}\`\nYou can now run commands without typing \`?\` first.`, 0xFFD700)).catch(() => {});

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`## <:wavieo_tick:1512706892713955372> No-Prefix Added`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**User** — <@${target.id}> \`${target.id}\`\n` +
                                `**Duration** — \`${entry.durationLabel}\`\n` +
                                `**Expires** — \`${db.formatExpiry(entry.expiresAt)}\`\n` +
                                `**Added by** — ${message.author}`
                            )
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `-# This user can now use commands without the \`?\` prefix.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ──────────────────────────────────────────────────────────────────────
        // np remove <user|id>
        // ──────────────────────────────────────────────────────────────────────
        if (sub === 'remove') {
            const target = await resolveUser(message, args[1], client);
            if (!target) return message.reply(createContainer('<:wavieo_cross:1512706979502755980> User not found. Use a mention or valid user ID.', 0xFF4444));

            const removed = db.removeUser(target.id);

            // DM the user if it was removed
            if (removed) {
                target.send(createContainer(`⚠️ Your **No-Prefix** access has been revoked by the bot owner.`, 0xFF4444)).catch(() => {});
            }

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                removed
                                    ? `## 🗑️ No-Prefix Removed\n> <@${target.id}> \`${target.id}\` no longer has no-prefix access.`
                                    : `## ⚠️ Not Found\n> <@${target.id}> does not have no-prefix access.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ──────────────────────────────────────────────────────────────────────
        // np list
        // ──────────────────────────────────────────────────────────────────────
        if (sub === 'list') {
            const users = db.listUsers();

            if (!users.length) {
                return message.reply({
                    components: [
                        new ContainerBuilder()
                            .setAccentColor(0xFFFFFF)
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `## 📋 No-Prefix List\n> No users currently have no-prefix access.\n> Use \`?np add <user> <duration>\` to add one.`
                                )
                            ),
                    ],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            const now = Date.now();
            const list = users.map((u, i) => {
                const timeLeft = u.expiresAt ? u.expiresAt - now : null;
                const expiry   = u.expiresAt
                    ? `⏳ \`${db.formatDuration(timeLeft)}\` left`
                    : `♾️ Permanent`;
                return (
                    `### ${i + 1}. <@${u.userId}> \`${u.userId}\`\n` +
                    `-# ${expiry}  •  Added by ${u.addedBy}  •  Since <t:${Math.floor(u.addedAt / 1000)}:R>`
                );
            }).join('\n\n');

            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`## 📋 No-Prefix Users`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(list)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `-# Total: \`${users.length}\` user${users.length !== 1 ? 's' : ''}`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ──────────────────────────────────────────────────────────────────────
        // np help (default)
        // ──────────────────────────────────────────────────────────────────────
        return message.reply({
            components: [
                new ContainerBuilder()
                    .setAccentColor(0xFFFFFF)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## 🔑 No-Prefix Manager`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `### \`?np add <@user|id> <duration>\`\n` +
                            `-# ↳ Grant no-prefix access. Duration: \`30m\` \`2h\` \`7d\`\n\n` +
                            `### \`?np remove <@user|id>\`\n` +
                            `-# ↳ Revoke no-prefix access from a user.\n\n` +
                            `### \`?np list\`\n` +
                            `-# ↳ View all active no-prefix users with expiry info.`
                        )
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `-# 🔒 Owner-only command  •  Prefix: \`?\``
                        )
                    ),
            ],
            flags: MessageFlags.IsComponentsV2,
        });
    },
};

// ─── Helper: resolve user from mention or ID ───────────────────────────────────
async function resolveUser(message, input, client) {
    if (!input) return null;
    // Strip mention format
    const id = input.replace(/[<@!>]/g, '');
    try {
        return await client.users.fetch(id);
    } catch {
        return null;
    }
}
