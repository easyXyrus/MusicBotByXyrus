const premiumDB = require('../../utils/premium');
const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } = require('discord.js');

const OWNER_ID = '1490225874585518150';

module.exports = {
    name: 'premium',
    aliases: ['prem'],
    category: 'admin',
    description: 'Check premium status or manage premium subscriptions (Owner only)',
    cooldown: 5,

    async execute(message, args, client) {
        const subcommand = args[0]?.toLowerCase();

        // ── STATUS Subcommand (Accessible by everyone) ────────────────────────────────
        if (!subcommand || subcommand === 'status') {
            if (!message.guild) {
                return message.reply('❌ This command can only be used within a server.');
            }

            try {
                const guildData = premiumDB.getPremiumData(message.guild.id);
                const isActive = guildData && guildData.premium && 
                    (!guildData.premiumUntil || new Date(guildData.premiumUntil).getTime() > Date.now());

                let statusText = '';
                if (isActive) {
                    if (!guildData.premiumUntil) {
                        statusText = `✨ **Premium Status**: **Active (Lifetime)**`;
                    } else {
                        const timestamp = Math.floor(new Date(guildData.premiumUntil).getTime() / 1000);
                        statusText = `✨ **Premium Status**: **Active**\n📅 **Expires**: <t:${timestamp}:F> (<t:${timestamp}:R>)`;
                    }
                } else {
                    statusText = `❌ **Premium Status**: **Inactive**\n*Premium features are currently locked for this server.*`;
                }

                const container = new ContainerBuilder()
                    .setAccentColor(isActive ? 0xFFFFFF : 0xFF4444)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## 👑 Server Premium Status`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(statusText)
                    );

                return message.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (err) {
                console.error('Error fetching premium status:', err);
                return message.reply('❌ An error occurred while checking premium status.');
            }
        }

        // ── Owner Only Check for the other subcommands ────────────────────────────────
        if (message.author.id !== OWNER_ID) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF4444)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🚫 Owner Only\n> You do not have permission to use premium management subcommands.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ── ACTIVATE Subcommand (Owner only) ──────────────────────────────────────────
        if (subcommand === 'activate') {
            let targetGuildId = args[1];
            let daysArg = args[2];

            // If the user typed 'guild' as the first parameter, shift the arguments
            if (targetGuildId?.toLowerCase() === 'guild') {
                targetGuildId = args[2];
                daysArg = args[3];
            }

            if (!targetGuildId) {
                return message.reply('❌ Please provide a Guild ID.\nUsage: `?premium activate [guild] <guildId> [days]`');
            }

            const days = daysArg ? parseInt(daysArg, 10) : 0;
            if (daysArg && isNaN(days)) {
                return message.reply('❌ Days must be a valid number.');
            }

            let premiumUntil = null;
            if (days > 0) {
                premiumUntil = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
            }

            try {
                premiumDB.setPremium(targetGuildId, true, premiumUntil);

                let targetGuildName = 'Unknown Guild (Not in bot cache/shared servers)';
                let dmSent = false;
                try {
                    const targetGuild = await client.guilds.fetch(targetGuildId);
                    if (targetGuild) {
                        targetGuildName = targetGuild.name;
                        const owner = await targetGuild.fetchOwner();
                        if (owner) {
                            const dmContainer = new ContainerBuilder()
                                .setAccentColor(0xFFFFFF)
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(
                                        `## 🎉 Premium Activated!\n\nHello **${owner.user.username}**,\nYour server **${targetGuild.name}** has been upgraded to **Premium**! ` +
                                        (premiumUntil 
                                            ? `It is valid until <t:${Math.floor(premiumUntil.getTime() / 1000)}:F> (<t:${Math.floor(premiumUntil.getTime() / 1000)}:R>).` 
                                            : `This is a **Lifetime** subscription.`) + 
                                        ` Enjoy the premium perks! 🎵`
                                    )
                                );
                            await owner.send({
                                components: [dmContainer],
                                flags: MessageFlags.IsComponentsV2
                            });
                            dmSent = true;
                        }
                    }
                } catch (err) {
                    console.warn(`Failed to notify server owner via DM: ${err.message}`);
                }

                const responseContainer = new ContainerBuilder()
                    .setAccentColor(0xFFFFFF)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## <:wavieo_tick:1512706892713955372> Premium Activated`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `**Guild Name** — **${targetGuildName}**\n` +
                            `**Guild ID** — \`${targetGuildId}\`\n` +
                            `**Duration** — ${days > 0 ? `\`${days}\` days` : `\`Lifetime\``}\n` +
                            (premiumUntil ? `**Expires** — <t:${Math.floor(premiumUntil.getTime() / 1000)}:F>\n` : '') +
                            `**Owner DM** — ${dmSent ? '✅ Sent' : '❌ Failed / DMs Closed'}`
                        )
                    );

                return message.reply({
                    content: `👑 **Premium Activated for ${targetGuildName}!**`,
                    components: [responseContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (err) {
                console.error('Error activating premium:', err);
                return message.reply('❌ An error occurred while activating premium.');
            }
        }

        // ── REVOKE Subcommand (Owner only) ───────────────────────────────────────────
        if (subcommand === 'revoke') {
            let targetId = args[1];

            // If the user typed 'guild' as the first parameter (e.g. `revoke guild <guildId>`), shift the arguments
            if (targetId?.toLowerCase() === 'guild') {
                targetId = args[2];
            }

            if (!targetId) {
                return message.reply('❌ Please provide a Guild ID.\nUsage: `?premium revoke [guild] <guildId>`');
            }

            try {
                const guildData = premiumDB.getPremiumData(targetId);
                if (!guildData) {
                    return message.reply('❌ No premium data found for this Guild.');
                }

                premiumDB.revokePremium(targetId);

                let targetGuildName = 'Unknown Guild (Not in bot cache/shared servers)';
                let dmSent = false;
                try {
                    const targetGuild = await client.guilds.fetch(targetId);
                    if (targetGuild) {
                        targetGuildName = targetGuild.name;
                        const owner = await targetGuild.fetchOwner();
                        if (owner) {
                            const dmContainer = new ContainerBuilder()
                                .setAccentColor(0xFF4444)
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(
                                        `## ⚠️ Premium Revoked\n\nHello **${owner.user.username}**,\nWe wanted to let you know that the **Premium** subscription for **${targetGuild.name}** has been revoked. If you believe this is an error, please contact the bot owner.`
                                    )
                                );
                            await owner.send({
                                components: [dmContainer],
                                flags: MessageFlags.IsComponentsV2
                            });
                            dmSent = true;
                        }
                    }
                } catch (err) {
                    console.warn(`Failed to notify server owner via DM: ${err.message}`);
                }

                const responseContainer = new ContainerBuilder()
                    .setAccentColor(0xFFFFFF)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## <:wavieo_cross:1512706979502755980> Premium Revoked`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `**Guild Name** — **${targetGuildName}**\n` +
                            `**Guild ID** — \`${targetId}\`\n` +
                            `**Owner DM** — ${dmSent ? '✅ Sent' : '❌ Failed / DMs Closed'}`
                        )
                    );

                return message.reply({
                    content: `❌ **Premium Revoked for ${targetGuildName}!**`,
                    components: [responseContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (err) {
                console.error('Error revoking premium:', err);
                return message.reply('❌ An error occurred while revoking premium.');
            }
        }

        return message.reply('❌ Unknown subcommand. Supported: `status`, `activate`, `revoke`.');
    }
};
