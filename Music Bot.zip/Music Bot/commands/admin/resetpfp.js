const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionsBitField,
} = require('discord.js');

const OWNER_ID = '1490225874585518150';

module.exports = {
    name: 'resetpfp',
    category: 'Customisation',
    aliases: ['resetavatar', 'rpfp', 'resetguildavatar'],
    description: "Reset the bot's server avatar back to default in this server.",
    usage: 'resetpfp',
    args: false,
    cooldown: 10,
    userPrams: [],
    botPrams: [],
    owner: false,

    execute: async (message, args, client, prefix) => {
        // ── Premium check ─────────────────────────────────────────────────
        const premiumDB = require('../../utils/premium');
        const hasPremium = premiumDB.hasPremium(message.author.id, message.guild.id);
        const isOwner = message.author.id === OWNER_ID;

        if (!hasPremium && !isOwner) {
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `❌ **Premium Required**\nThis server does not have an active Premium subscription. Upgrading to premium unlocks custom server-specific profile pictures!`
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        // ── Permission check ──────────────────────────────────────────────
        const isGuildOwner = message.guild.ownerId === message.author.id;
        const hasManage = message.member.permissions.has(PermissionsBitField.Flags.ManageGuild);

        if (!isOwner && !isGuildOwner && !hasManage) {
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:wavieo_cross:1512706979502755980> You need the **Manage Server** permission (or be the server owner) to use this command.`
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const loadingMsg = await message.reply({ content: '<a:wavieo_loading:1512872779622383811> Resetting avatar…' });

        try {
            await message.guild.members.editMe({ avatar: null });

            await loadingMsg.delete().catch(() => {});

            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# <:wavieo_tick:1512706892713955372> Server Avatar Reset`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `Successfully reset the bot's profile picture to default in this server.`
                )
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`-# Reset by ${message.author.username}`)
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });

        } catch (err) {
            await loadingMsg.delete().catch(() => {});
            console.error('[resetpfp] Discord API error:', err);

            let hint = err.message || 'Unknown error.';
            if (err.code === 50013) hint = 'The bot is missing permissions to edit its own guild profile.';

            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:wavieo_cross:1512706979502755980> Failed to reset the server avatar: \`${hint}\``
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
