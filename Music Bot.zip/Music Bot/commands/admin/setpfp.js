const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionsBitField,
} = require('discord.js');
const { fetchImageBuffer, isValidImageUrl } = require('../../utils/imageToBuffer');

const OWNER_ID = '1490225874585518150';

module.exports = {
    name: 'setpfp',
    category: 'Customisation',
    aliases: ['setavatar', 'serverpfp'],
    description: "Set a custom bot avatar for this server only using Discord's per-guild profile feature.",
    usage: 'setpfp <image URL | attachment>',
    args: false,
    cooldown: 15,
    userPrams: [],   // permission checked manually below
    botPrams: [],
    owner: false,

    execute: async (message, args, client, prefix) => {
        // ── Premium check ─────────────────────────────────────────────────
        const premiumDB = require('../../utils/premium');
        const hasPremium = premiumDB.hasPremium(message.author.id, message.guild.id);
        const isOwner = message.author.id === OWNER_ID;

        if (!hasPremium && !isOwner) {
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `❌ **Premium Required**\nThis server does not have an active Premium subscription. Upgrading to premium unlocks custom server-specific profile pictures!`
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        // ── Permission check ──────────────────────────────────────────────
        const isGuildOwner = message.guild.ownerId === message.author.id;
        const hasManage = message.member.permissions.has(PermissionsBitField.Flags.ManageGuild);

        if (!isOwner && !isGuildOwner && !hasManage) {
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:wavieo_cross:1512706979502755980> You need the **Manage Server** permission (or be the server owner) to use this command.`
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        // ── Resolve image URL ─────────────────────────────────────────────
        let imageUrl = args[0] || null;
        const attachment = message.attachments.first();
        if (attachment) imageUrl = attachment.url;

        if (!imageUrl) {
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# Set Server Bot Avatar`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `Set a custom bot avatar that only appears in **this server** using Discord's native per-guild profile feature.\n\n` +
                    `**Usage**\n` +
                    `> \`${prefix}setpfp <image URL>\`\n` +
                    `> \`${prefix}setpfp\` *(with an attached image)*\n\n` +
                    `**Supported formats:** PNG, JPG, GIF, WEBP — max 10 MB\n\n` +
                    `The bot's global avatar stays unchanged everywhere else.`
                )
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`-# Requested by ${message.author.username}`)
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        // Basic URL sanity check
        if (!isValidImageUrl(imageUrl)) {
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:wavieo_cross:1512706979502755980> That doesn't look like a valid image URL. Supported formats: \`png\`, \`jpg\`, \`jpeg\`, \`gif\`, \`webp\`.`
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        // ── Fetch image ───────────────────────────────────────────────────
        const loadingMsg = await message.reply({ content: '<a:wavieo_loading:1512872779622383811> Fetching image…' });

        let imageBuffer;
        try {
            const result = await fetchImageBuffer(imageUrl);
            imageBuffer = result.buffer;
        } catch (err) {
            await loadingMsg.delete().catch(() => {});
            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:wavieo_cross:1512706979502755980> Failed to fetch the image: \`${err.message}\``
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        // ── Apply via Discord's per-guild profile API ─────────────────────
        try {
            await message.guild.members.editMe({ avatar: imageBuffer });

            await loadingMsg.delete().catch(() => {});

            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# <:wavieo_tick:1512706892713955372> Server Avatar Updated`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `*Use \`${prefix}resetpfp\` to revert back to the default avatar in this server.*`
                )
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`-# Set by ${message.author.username}`)
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });

        } catch (err) {
            await loadingMsg.delete().catch(() => {});
            console.error('[setpfp] Discord API error:', err);

            // Provide a helpful message for common API errors
            let hint = err.message || 'Unknown error.';
            if (err.code === 50035) hint = 'The image format or size was rejected by Discord. Try a smaller PNG or JPG.';
            if (err.code === 50013) hint = 'The bot is missing permissions to edit its own guild profile.';

            const container = new ContainerBuilder().setAccentColor(0xFFFFFF);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `<:wavieo_cross:1512706979502755980> Failed to update the server avatar: \`${hint}\``
                )
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    },
};
