const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MessageFlags,
} = require('discord.js');
const prefixDB = require('../../utils/prefixDB');

const MAX_PREFIX_LENGTH = 5;

module.exports = {
    name: 'setprefix',
    aliases: ['sp'],
    category: 'admin',
    description: 'Set a custom prefix for this server',
    cooldown: 10,

    async execute(message, args, client) {

        // ── Permission check: needs Manage Guild ───────────────────────────────
        if (
            !message.member.permissions.has('ManageGuild') &&
            message.author.id !== '1490225874585518150'
        ) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFF4444)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🚫 Missing Permission\n> You need **Manage Server** permission to change the prefix.`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const currentPrefix = prefixDB.getPrefix(message.guild.id);
        const newPrefix     = args[0];

        // ── Show current prefix if no arg ──────────────────────────────────────
        if (!newPrefix) {
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🔧 Server Prefix`
                            )
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**Current Prefix** — \`${currentPrefix}\`\n` +
                                `**Global Default** — \`${prefixDB.GLOBAL_PREFIX}\`\n\n` +
                                `To change: \`${currentPrefix}setprefix <new prefix>\`\n` +
                                `To reset:  \`${currentPrefix}setprefix reset\``
                            )
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `-# Max ${MAX_PREFIX_LENGTH} characters  •  Requires Manage Server`
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ── Reset to global ────────────────────────────────────────────────────
        if (newPrefix.toLowerCase() === 'reset') {
            prefixDB.resetPrefix(message.guild.id);
            return message.reply({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(0xFFFFFF)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `## 🔄 Prefix Reset\n> This server is back to the global prefix: \`${prefixDB.GLOBAL_PREFIX}\``
                            )
                        ),
                ],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        // ── Validation ─────────────────────────────────────────────────────────
        if (newPrefix.length > MAX_PREFIX_LENGTH) {
            return message.reply(`<:wavieo_cross:1512706979502755980> Prefix too long! Max **${MAX_PREFIX_LENGTH}** characters.`);
        }
        if (/\s/.test(newPrefix)) {
            return message.reply(`<:wavieo_cross:1512706979502755980> Prefix cannot contain spaces.`);
        }

        // ── Save ───────────────────────────────────────────────────────────────
        prefixDB.setPrefix(message.guild.id, newPrefix);

        return message.reply({
            components: [
                new ContainerBuilder()
                    .setAccentColor(0xFFFFFF)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## <:wavieo_tick:1512706892713955372> Prefix Updated`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `**Old Prefix** — \`${currentPrefix}\`\n` +
                            `**New Prefix** — \`${newPrefix}\`\n\n` +
                            `All commands now use \`${newPrefix}\` in this server.\n` +
                            `-# Example: \`${newPrefix}play <song>\`, \`${newPrefix}help\``
                        )
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `-# To reset: \`${newPrefix}setprefix reset\`  •  Requested by ${message.author}`
                        )
                    ),
            ],
            flags: MessageFlags.IsComponentsV2,
        });
    },
};
