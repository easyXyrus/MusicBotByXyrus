const afkDB = require('../utils/afk');
const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } = require('discord.js');

module.exports = {
    name: 'afk',
    category: 'General',
    description: 'Set yourself as AFK (Away From Keyboard) with a reason.',
    usage: 'afk [reason]',
    cooldown: 5,

    async execute(message, args, client) {
        const reason = args.join(' ') || 'I am AFK';
        
        afkDB.setAFK(message.author.id, reason);

        const container = new ContainerBuilder()
            .setAccentColor(0xFFFFFF)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# <:wavieo_tick:1512706892713955372> AFK Status Set\n\n` +
                    `${message.author}, I have set your status to AFK.\n` +
                    `📝 **Reason:** ${reason}`
                )
            );

        return message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
