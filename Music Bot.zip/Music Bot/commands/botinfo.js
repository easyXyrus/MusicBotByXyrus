const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');
const os = require('os');

module.exports = {
    name: 'botinfo',
    aliases: ['bi'],
    description: 'Displays detailed information and statistics about the bot',
    category: 'General',
    async execute(message, args, client) {
        // Calculate uptime
        const totalSeconds = (client.uptime / 1000);
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor(totalSeconds / 3600) % 24;
        const minutes = Math.floor(totalSeconds / 60) % 60;
        const seconds = Math.floor(totalSeconds % 60);
        const uptime = `${days}d ${hours}h ${minutes}m ${seconds}s`;

        // Calculate memory
        const memoryUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
        const totalMemory = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);

        // Fetch Lavalink info
        const lavalinkNodes = Array.from(client.lavalink.nodeManager.nodes.values()).map(n => n.connected ? '🟢 Connected' : '🔴 Disconnected').join(', ') || 'None';
        const activePlayers = client.lavalink.players ? client.lavalink.players.size : (client.lavalink.playerManager ? client.lavalink.playerManager.players.size : 0);

        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setAuthor({ name: `${client.user.username} Information`, iconURL: client.user.displayAvatarURL() })
            .setThumbnail(client.user.displayAvatarURL({ size: 512 }))
            .addFields(
                { name: '🤖  Bot Stats', value: `**Servers:** ${client.guilds.cache.size}\n**Users:** ${client.users.cache.size}\n**Ping:** ${client.ws.ping}ms`, inline: true },
                { name: '🎵  Music Stats', value: `**Active Players:** ${activePlayers}\n**Lavalink:** ${lavalinkNodes}`, inline: true },
                { name: '💻  System', value: `**Memory:** ${memoryUsed} MB\n**Uptime:** ${uptime}\n**Node.js:** ${process.version}`, inline: false }
            )
            .setFooter({ text: `Requested by ${message.author.username}` })
            .setTimestamp();

        message.reply({ embeds: [embed] });
    }
};
