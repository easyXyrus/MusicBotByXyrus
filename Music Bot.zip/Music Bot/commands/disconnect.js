const { createContainer } = require('../utils/containerUI');
module.exports = {
    name: 'disconnect',
    aliases: ['dc'],
    description: 'Disconnect from the voice channel',
    cooldown: 5,
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);

        if (!player)
            return message.reply(createContainer("<:wavieo_cross:1512706979502755980> I'm not in a voice channel.", 0xFF4444));

        const channelName = message.guild.channels.cache.get(player.voiceChannelId)?.name || 'voice channel';

        await player.destroy();

        message.reply(createContainer(`👋 Disconnected from **${channelName}**`));
    },
};
