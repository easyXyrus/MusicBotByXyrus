const { FILTERS, FILTER_PRESETS } = require('../utils/playerUI');
const { ContainerBuilder } = require('discord.js');

// Simple helper to match the createContainer format used elsewhere
function createContainer(text) {
    return new ContainerBuilder()
        .setAccentColor(0xFFFFFF)
        .addTextDisplayComponents(text);
}

module.exports = {
    name: 'filter',
    aliases: ['f'],
    description: 'Apply an audio filter to the current track',
    category: 'Music',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.queue.current) {
            return message.reply('<:wavieo_cross:1512706979502755980> There is nothing currently playing.');
        }

        const member = message.member;
        if (member?.voice?.channelId !== player.voiceChannelId) {
            return message.reply('<:wavieo_cross:1512706979502755980> You must be in the same voice channel to use filters.');
        }

        const filterQuery = args[0]?.toLowerCase();

        // If no arguments or 'list', show available filters
        if (!filterQuery || filterQuery === 'list') {
            const filterList = FILTERS.map(f => `${f.emoji} **${f.value}** - ${f.description}`).join('\n');
            return message.reply(`**Available Filters:**\n\n${filterList}\n\n*Usage:* \`?filter <name>\``);
        }

        const preset = FILTER_PRESETS[filterQuery];
        if (!preset) {
            return message.reply(`<:wavieo_cross:1512706979502755980> Invalid filter! Use \`?filter list\` to see all available filters.`);
        }

        try {
            await preset(player.filterManager);
            const filterDef = FILTERS.find(f => f.value === filterQuery);
            const filterName = filterDef ? filterDef.label : filterQuery;
            
            return message.reply(`🎛️ Successfully applied the **${filterName}** filter!`);
        } catch (err) {
            console.error('Error applying filter:', err);
            return message.reply('<:wavieo_cross:1512706979502755980> Failed to apply the filter.');
        }
    }
};
