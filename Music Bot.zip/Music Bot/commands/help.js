const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require('discord.js');

// ─── Category Definitions ─────────────────────────────────────────────────────
const CATEGORIES = {
    music: {
        emoji: '🎵',
        label: 'Music',
        color: 0xFFFFFF,
        description: 'Music playback, queue & filter controls',
        commands: [
            { cmd: '?play <song / url>', desc: 'Play music in voice channel' },
            { cmd: '?pause',             desc: 'Pause playback' },
            { cmd: '?resume',            desc: 'Resume playback' },
            { cmd: '?skip',              desc: 'Skip current song' },
            { cmd: '?stop',              desc: 'Stop playback & leave channel' },
            { cmd: '?join',              desc: 'Summon bot to voice channel' },
            { cmd: '?disconnect',        desc: 'Disconnect bot from channel' },
            { cmd: '?queue',             desc: 'View music queue list' },
            { cmd: '?nowplaying',        desc: 'Show details of playing song' },
            { cmd: '?shuffle',           desc: 'Shuffle queue tracks' },
            { cmd: '?loop',              desc: 'Cycle loop modes' },
            { cmd: '?volume <0-100>',    desc: 'Change playback volume' },
            { cmd: '?filter <preset>',   desc: 'Set audio filters (bassboost, nightcore, etc.)' },
        ],
    },
    customisation: {
        emoji: '🎨',
        label: 'Customisation',
        color: 0xFFFFFF,
        description: 'Server bot profile customization (Premium)',
        commands: [
            { cmd: '?setpfp <image>',    desc: 'Set custom bot avatar for this server' },
            { cmd: '?resetpfp',          desc: 'Reset bot avatar to default' },
            { cmd: '?setbanner <image>', desc: 'Set custom bot banner for this server' },
            { cmd: '?resetbanner',       desc: 'Reset bot banner to default' },
        ],
    },
    management: {
        emoji: '⚙️',
        label: 'Management',
        color: 0xFFFFFF,
        description: 'Bot configuration & admin management',
        commands: [
            { cmd: '?premium status',    desc: 'Check server premium status' },
            { cmd: '?premium <subcmd>',  desc: 'Manage server premium subscription (Bot Owner)' },
            { cmd: '?setprefix <prefix>', desc: 'Set custom prefix for this server' },
            { cmd: '?24/7',              desc: 'Toggle 24/7 mode' },
            { cmd: '?np',                desc: 'Configure now-playing message styling (Admin only)' },
        ],
    },
    info: {
        emoji: 'ℹ️',
        label: 'Information',
        color: 0xFFFFFF,
        description: 'General info & bot utility commands',
        commands: [
            { cmd: '?afk [reason]',      desc: 'Set yourself as AFK' },
            { cmd: '?botinfo',           desc: 'Show bot uptime, ping, host info & memory' },
            { cmd: '?invite',            desc: 'Get the invite link for Wavieo' },
            { cmd: '?support',           desc: 'Get the support server invite link' },
            { cmd: '?help',              desc: 'Open this help panel' },
        ],
    },
};

// ─── Build Main Home Container ────────────────────────────────────────────────
function buildHomeContainer(client) {
    const totalCmds = Object.values(CATEGORIES).reduce((a, c) => a + c.commands.length, 0);

    return new ContainerBuilder()
        .setAccentColor(0xFFFFFF)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🎵 ${client.user.username} — Help\n` +
                `> Welcome! Browse the categories below to discover all commands.`
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**🎵 Music** — Playback, queue, loop, volume & filter controls\n` +
                `**🎨 Customisation** — Set server bot avatars & banners (Premium)\n` +
                `**⚙️ Management** — Premium activation, custom prefixes & 24/7 toggle\n` +
                `**ℹ️ Information** — Bot diagnostics, system status & help`
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `\`${totalCmds}\` Commands  •  Prefix: \`?\`  •  Lavalink v4`
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(false).setSpacing(1))
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('help_category')
                    .setPlaceholder('📂  Select a category to explore...')
                    .addOptions(
                        Object.entries(CATEGORIES).map(([value, cat]) =>
                            new StringSelectMenuOptionBuilder()
                                .setLabel(cat.label)
                                .setDescription(cat.description)
                                .setValue(value)
                                .setEmoji(cat.emoji)
                        )
                    )
            )
        );
}

// ─── Build Category Container ──────────────────────────────────────────────────
function buildCategoryContainer(categoryKey) {
    const cat = CATEGORIES[categoryKey];
    if (!cat) return buildHomeContainer();

    const commandList = cat.commands
        .map(c => `### \`${c.cmd}\`\n-# ↳ ${c.desc}`)
        .join('\n\n');

    return new ContainerBuilder()
        .setAccentColor(0xFFFFFF)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ${cat.emoji} ${cat.label}\n` +
                `> ${cat.description}`
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(commandList)
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(1))
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`-# Prefix: \`?\`  •  Select another category or go home`)
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(false).setSpacing(1))
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('help_category')
                    .setPlaceholder(`${cat.emoji}  ${cat.label} — pick another...`)
                    .addOptions(
                        Object.entries(CATEGORIES).map(([value, c]) =>
                            new StringSelectMenuOptionBuilder()
                                .setLabel(c.label)
                                .setDescription(c.description)
                                .setValue(value)
                                .setEmoji(c.emoji)
                                .setDefault(value === categoryKey)
                        )
                    )
            )
        )
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('help_home')
                    .setLabel('Home')
                    .setEmoji('🏠')
                    .setStyle(ButtonStyle.Secondary)
            )
        );
}

module.exports = {
    name: 'help',
    buildHomeContainer,
    buildCategoryContainer,
    async execute(message, args, client) {
        message.reply({
            components: [buildHomeContainer(client)],
            flags: MessageFlags.IsComponentsV2,
        });
    },
};
