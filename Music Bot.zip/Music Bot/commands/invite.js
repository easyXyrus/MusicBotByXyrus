const { ContainerBuilder, TextDisplayBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

module.exports = {
    name: 'invite',
    description: 'Get the invite link for Wavieo.',
    category: 'General',
    cooldown: 5,

    async execute(message, args, client) {
        const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=70918606290129&integration_type=0&scope=bot`;

        const container = new ContainerBuilder()
            .setAccentColor(0xFFFFFF)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## 🎉 Invite Wavieo\n` +
                    `Click the button below to invite **${client.user.username}** to your server!`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Invite Me!')
                        .setEmoji('🔗')
                        .setStyle(ButtonStyle.Link)
                        .setURL(inviteUrl)
                )
            );

        return message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
