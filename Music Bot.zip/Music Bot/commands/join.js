const { createContainer } = require('../utils/containerUI');
module.exports = {
    name: 'join',
    aliases: ['j'],
    description: 'Join your voice channel',
    cooldown: 5,
    async execute(message, args, client) {
        const voiceChannel = message.member?.voice?.channel;
        if (!voiceChannel)
            return message.reply(createContainer('<:wavieo_cross:1512706979502755980> You need to be in a voice channel to use this command.', 0xFF4444));

        const permissions = voiceChannel.permissionsFor(message.guild.members.me);
        if (!permissions.has('Connect') || !permissions.has('Speak'))
            return message.reply(createContainer('<:wavieo_cross:1512706979502755980> I need the permissions to join and speak in your voice channel!', 0xFF4444));

        try {
            let player = client.lavalink.getPlayer(message.guild.id);

            if (player) {
                if (player.voiceChannelId === voiceChannel.id) {
                    return message.reply(createContainer('<:wavieo_cross:1512706979502755980> I am already in your voice channel!', 0xFF4444));
                }
                await player.setVoiceChannel(voiceChannel.id);
            } else {
                player = await client.lavalink.createPlayer({
                    guildId: message.guild.id,
                    voiceChannelId: voiceChannel.id,
                    textChannelId: message.channel.id,
                    selfDeaf: true,
                    selfMute: false,
                    volume: 80,
                });
                await player.connect();
            }

            message.reply(createContainer(`🔊 Joined **${voiceChannel.name}**`));
        } catch (err) {
            console.error('[join]', err);
            message.reply(createContainer(`<:wavieo_cross:1512706979502755980> Failed to join: ${err.message}`, 0xFF4444));
        }
    },
};
