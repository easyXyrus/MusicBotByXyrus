const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'loop',
    description: 'Toggle loop mode (off / track / queue)',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.queue.current)
            return message.reply(createContainer(''));

        const current = player.repeatMode;
        let newMode, icon, label;
        if (current === 'none') {
            newMode = 'track'; icon = '🔂'; label = 'Track Loop';
        } else if (current === 'track') {
            newMode = 'queue'; icon = '🔁'; label = 'Queue Loop';
        } else {
            newMode = 'none'; icon = '➡️'; label = 'Loop Off';
        }
        await player.setRepeatMode(newMode);

        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription(`${icon}  Loop mode set to **${label}**`)
            .setFooter({ text: `Changed by ${message.author.tag}` });
        message.reply({ embeds: [embed] });
    },
};
