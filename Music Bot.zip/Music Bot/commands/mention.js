const {
    ContainerBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require('discord.js');

module.exports = {
    name: 'mention',
    description: 'Replies when the bot is mentioned',
    execute(message, client) {

        const container = new ContainerBuilder()
            .addSectionComponents(
                new SectionBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `## ${client.user.username}\n` +
                            `Hey ${message.author}, You have reached out to **${client.user.username}**,`
                        )
                    )
                    .setThumbnailAccessory(
                        new ThumbnailBuilder()
                            .setURL(client.user.displayAvatarURL({ extension: 'png', size: 1024 }))
                            .setDescription('Bot Avatar')
                    )
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `> My prefix is \`?\`\n` +
                    `> Use \`?help\` to see my commands!\n` +
                    `> You can also mention me to use commands!`
                )
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(1)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `-# Requested by ${message.author.username}`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Invite Me!')
                        .setEmoji('🔗')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.com/oauth2/authorize?client_id=1512655379048435883&permissions=70918606290129&integration_type=0&scope=bot'),
                    new ButtonBuilder()
                        .setLabel('Support Server!')
                        .setEmoji('🔗')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.gg/yourinvite')
                )
            );

        message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
        });
    },
};
