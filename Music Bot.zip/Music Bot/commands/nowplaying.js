const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'nowplaying',
    aliases: ['nop'],
    description: 'Show the currently playing song',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.queue.current)
            return message.reply(createContainer(''));

        const track = player.queue.current;
        const pos = player.position;
        const dur = track.info.duration;
        const bar = buildBar(pos, dur, 18);
        const loopIcon = player.repeatMode === 'track' ? '🔂' : player.repeatMode === 'queue' ? '🔁' : '➡️';

        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setAuthor({ name: '🎵  Now Playing' })
            .setTitle(track.info.title)
            .setURL(track.info.uri)
            .setDescription(
                `by **${track.info.author || 'Unknown'}**\n\n` +
                `\`${formatDuration(pos)}\`  ${bar}  \`${formatDuration(dur)}\``
            )
            .addFields(
                { name: '👤  Requested by', value: `<@${track.requester?.id || track.requester}>`, inline: true },
                { name: '🔊  Volume', value: `\`${player.volume}%\``, inline: true },
                { name: '🔄  Loop', value: loopIcon, inline: true },
                { name: '📋  In Queue', value: `\`${player.queue.tracks.length} tracks\``, inline: true },
            )
            .setThumbnail(track.info.artworkUrl || null)
            .setFooter({ text: track.info.sourceName ? `Source: ${track.info.sourceName}` : 'Music Bot' })
            .setTimestamp();

        message.reply({ embeds: [embed] });
    },
};

function buildBar(current, total, size) {
    if (!total) return '━'.repeat(size);
    const progress = Math.min(Math.floor((current / total) * size), size - 1);
    return '━'.repeat(progress) + '⬤' + '╌'.repeat(size - progress - 1);
}

function formatDuration(ms) {
    if (!ms) return 'LIVE';
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
        ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
        : `${m}:${String(sec).padStart(2, '0')}`;
}
