const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'pause',
    description: 'Pause the current song',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.playing)
            return message.reply(createContainer(''));
        if (player.paused)
            return message.reply(createContainer(''));
        await player.pause();
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription('⏸  Playback **paused** — use `?resume` to continue.')
            .setFooter({ text: `Paused by ${message.author.tag}` });
        message.reply({ embeds: [embed] });
    },
};
