const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'play',
    aliases: ['p'],
    description: 'Play a song by name or URL',
    async execute(message, args, client) {
        const query = args.join(' ');
        if (!query)
            return message.reply(createContainer('<:wavieo_cross:1512706979502755980> Please provide a song name or URL!'));

        const voiceChannel = message.member?.voice?.channel;
        if (!voiceChannel)
            return message.reply(createContainer('<:wavieo_cross:1512706979502755980> You need to be in a voice channel to play music!'));

        const permissions = voiceChannel.permissionsFor(message.guild.members.me);
        if (!permissions.has('Connect') || !permissions.has('Speak'))
            return message.reply(createContainer('<:wavieo_cross:1512706979502755980> I need the permissions to join and speak in your voice channel!'));

        await message.channel.sendTyping();

        try {
            let player = client.lavalink.getPlayer(message.guild.id);
            if (!player) {
                player = await client.lavalink.createPlayer({
                    guildId: message.guild.id,
                    voiceChannelId: voiceChannel.id,
                    textChannelId: message.channel.id,
                    selfDeaf: true,
                    selfMute: false,
                    volume: 80,
                });
            }

            if (!player.connected) await player.connect();

            const res = await player.search({ query }, message.author);

            if (!res || !res.tracks?.length)
                return message.reply(createContainer('<:wavieo_cross:1512706979502755980> No results found.'));

            if (res.loadType === 'playlist') {
                await player.queue.add(res.tracks);
                const embed = new EmbedBuilder()
                    .setColor('#FFFFFF')
                    .setAuthor({ name: '📋  Playlist Queued', iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                    .setTitle(res.playlist?.title || 'Playlist')
                    .setDescription(
                        `> Added **${res.tracks.length} tracks** to the queue.\n` +
                        `> Playback will begin shortly.`
                    )
                    .setFooter({ text: `Requested by ${message.author.tag}` })
                    .setTimestamp();
                message.reply({ embeds: [embed] });
            } else {
                const track = res.tracks[0];
                await player.queue.add(track);

                if (!player.playing) {
                    await player.play({ paused: false });
                } else {
                    const embed = new EmbedBuilder()
                        .setColor('#FFFFFF')
                        .setAuthor({ name: '➕  Added to Queue', iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                        .setTitle(track.info.title)
                        .setURL(track.info.uri)
                        .setDescription(`by **${track.info.author || 'Unknown'}**`)
                        .addFields(
                            { name: '⏱  Duration', value: `\`${formatDuration(track.info.duration)}\``, inline: true },
                            { name: '🔢  Position', value: `\`#${player.queue.tracks.length}\``, inline: true }
                        )
                        .setThumbnail(track.info.artworkUrl || null)
                        .setFooter({ text: `Requested by ${message.author.tag}` })
                        .setTimestamp();
                    message.reply({ embeds: [embed] });
                }
            }
        } catch (err) {
            console.error('[play] Error:', err);
            message.reply(createContainer(`<:wavieo_cross:1512706979502755980> Failed to play: ${err.message}`));
        }
    },
};

function formatDuration(ms) {
    if (!ms) return 'LIVE';
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
        ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
        : `${m}:${String(sec).padStart(2, '0')}`;
}
