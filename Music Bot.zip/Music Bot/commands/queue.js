const { createContainer } = require('../utils/containerUI');
module.exports = {
    name: 'queue',
    aliases: ['q'],
    description: 'Show the current queue',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.queue.current)
            return message.reply(createContainer('<:wavieo_cross:1512706979502755980> No music is currently playing!', 0xFF4444));

        const current = player.queue.current;
        const tracks = player.queue.tracks;
        const totalDuration = tracks.reduce((acc, t) => acc + (t.info.duration || 0), 0);

        const queueList = tracks.length > 0
            ? tracks.slice(0, 10).map((t, i) =>
                `\`${String(i + 1).padStart(2, '0')}.\` **[${t.info.title}](${t.info.uri})**\n` +
                `　　└ ${t.info.author || 'Unknown'} · \`${formatDuration(t.info.duration)}\``
              ).join('\n')
            : '> *No upcoming tracks — add more with `?play`*';

        const text = `## 📜 Queue\n\n**Currently Playing:**\n**[${current.info.title}](${current.info.uri})**\n\n**Upcoming:**\n${queueList}\n\n**Total Tracks:** ${tracks.length}`;
        message.reply(createContainer(text));
    },
};

function formatDuration(ms) {
    if (!ms) return 'LIVE';
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
        ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
        : `${m}:${String(sec).padStart(2, '0')}`;
}
