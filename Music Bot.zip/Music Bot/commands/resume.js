const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'resume',
    description: 'Resume the paused song',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player)
            return message.reply(createContainer(''));
        if (!player.paused)
            return message.reply(createContainer(''));
        await player.resume();
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription('▶  Playback **resumed**!')
            .setFooter({ text: `Resumed by ${message.author.tag}` });
        message.reply({ embeds: [embed] });
    },
};
