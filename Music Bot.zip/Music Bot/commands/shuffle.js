const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'shuffle',
    description: 'Shuffle the queue',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.queue.tracks.length)
            return message.reply(createContainer(''));
        await player.queue.shuffle();
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription(`🔀  Queue shuffled! **${player.queue.tracks.length}** tracks randomized.`)
            .setFooter({ text: `Shuffled by ${message.author.tag}` });
        message.reply({ embeds: [embed] });
    },
};
