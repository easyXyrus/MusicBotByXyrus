const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'skip',
    description: 'Skip the current song',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player || !player.playing)
            return message.reply(createContainer(''));
        const skipped = player.queue.current;
        await player.skip();
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription(`⏭  Skipped **[${skipped?.info?.title || 'track'}](${skipped?.info?.uri || ''})**`)
            .setFooter({ text: `Skipped by ${message.author.tag}` });
        message.reply({ embeds: [embed] });
    },
};
