const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'stop',
    description: 'Stop music and disconnect',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player)
            return message.reply(createContainer(''));
        await player.destroy();
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription('⏹  Stopped playback and disconnected from voice.')
            .setFooter({ text: `Stopped by ${message.author.tag}` });
        message.reply({ embeds: [embed] });
    },
};
