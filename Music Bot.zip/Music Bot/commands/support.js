const { ContainerBuilder, TextDisplayBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

module.exports = {
    name: 'support',
    description: 'Get the invite link for the support server.',
    category: 'General',
    cooldown: 5,

    async execute(message, args, client) {
        const supportUrl = 'https://discord.gg/yourinvite';

        const container = new ContainerBuilder()
            .setAccentColor(0xFFFFFF)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## 🛠️ Support Server\n` +
                    `Need help or have questions? Join our support server by clicking the button below!`
                )
            )
            .addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Support Server!')
                        .setEmoji('🔗')
                        .setStyle(ButtonStyle.Link)
                        .setURL(supportUrl)
                )
            );

        return message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
