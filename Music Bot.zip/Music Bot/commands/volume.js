const { createContainer } = require('../utils/containerUI');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'volume',
    description: 'Set the volume (0-100)',
    async execute(message, args, client) {
        const player = client.lavalink.getPlayer(message.guild.id);
        if (!player)
            return message.reply(createContainer(createContainer('')));

        const vol = parseInt(args[0]);
        if (isNaN(vol) || vol < 0 || vol > 100)
            return message.reply(createContainer(createContainer('')));

        await player.setVolume(vol);
        const bar = buildVolumeBar(vol, 15);
        const embed = new EmbedBuilder()
            .setColor('#FFFFFF')
            .setDescription(`🔊  Volume — ${bar} **${vol}%**`)
            .setFooter({ text: `Changed by ${message.author.tag}` });
        message.reply(createContainer({ embeds: [embed] }));
    },
};

function buildVolumeBar(vol, size) {
    const filled = Math.round((vol / 100) * size);
    return '█'.repeat(filled) + '░'.repeat(size - filled);
}
