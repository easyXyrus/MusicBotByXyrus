require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const { LavalinkManager } = require('lavalink-client');
const fs = require('fs');
const path = require('path');
// ─── Client Setup ─────────────────────────────────────────────────────────────
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent,
    ],
});

// ─── Lavalink Manager ─────────────────────────────────────────────────────────
client.lavalink = new LavalinkManager({
    nodes: [
        {
            authorization: process.env.LAVALINK_PASSWORD,
            host: process.env.LAVALINK_HOST,
            port: Number(process.env.LAVALINK_PORT),
            id: 'Main',
            secure: process.env.LAVALINK_SECURE === 'true',
        },
    ],
    sendToShard: (guildId, payload) => {
        const guild = client.guilds.cache.get(guildId);
        if (guild) guild.shard.send(payload);
    },
    client: {
        id: process.env.CLIENT_ID || '0',
        username: 'Wavieo',
    },
    playerOptions: {
        defaultSearchPlatform: 'ytsearch',
        volumeDecrementer: 0.75,
        onDisconnect: {
            autoReconnect: true,
            destroyPlayer: false,
        },
    },
    autoSkip: true,
});

// ─── Forward raw gateway events to Lavalink ───────────────────────────────────
client.on('raw', (d) => client.lavalink.sendRawData(d));

// ─── Command Collection (recursive) ─────────────────────────────────────────
client.commands = new Collection();

function loadCommands(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
            loadCommands(fullPath);
        } else if (entry.name.endsWith('.js')) {
            const command = require(fullPath);
            if (command.name) {
                client.commands.set(command.name, command);
                // Register each alias pointing to the same command
                if (command.aliases?.length) {
                    command.aliases.forEach(alias => client.commands.set(alias, command));
                    console.log(`📦 Loaded command: ${command.name} [aliases: ${command.aliases.join(', ')}]${command.category ? ` [${command.category}]` : ''}`);
                } else {
                    console.log(`📦 Loaded command: ${command.name}${command.category ? ` [${command.category}]` : ''}`);
                }
            }
        }
    }
}

loadCommands(path.join(__dirname, 'commands'));

// ─── Lavalink Node Events ─────────────────────────────────────────────────────
client.lavalink.nodeManager.on('connect', (node) => {
    console.log(`<:wavieo_tick:1512706892713955372> Lavalink Node "${node.id}" connected!`);
});

client.lavalink.nodeManager.on('error', (node, error) => {
    console.error(`<:wavieo_cross:1512706979502755980> Lavalink Node "${node.id}" error:`, error?.message || error);
});

client.lavalink.nodeManager.on('disconnect', (node) => {
    console.warn(`⚠️ Lavalink Node "${node.id}" disconnected.`);
});

// ─── Lavalink Player Events ───────────────────────────────────────────────────
const { buildPlayerContainer, FILTER_PRESETS } = require('./utils/playerUI');
const { generatePlayerBanner } = require('./utils/canvasUI');
const { createContainer } = require('./utils/containerUI');
const { MessageFlags, AttachmentBuilder } = require('discord.js');
const db247 = require('./utils/db247');

// ─── Voice Status Helper ──────────────────────────────────────────────────
async function setVoiceStatus(voiceChannelId, status) {
    if (!voiceChannelId) return;
    try {
        await client.rest.put(`/channels/${voiceChannelId}/voice-status`, {
            body: { status },
        });
    } catch (err) {
        console.warn('[voice status]', err.message);
    }
}

client.lavalink.on('trackStart', async (player, track) => {
    // Clear any pending auto-disconnect timeout
    if (player.emptyTimeout) {
        clearTimeout(player.emptyTimeout);
        player.emptyTimeout = null;
    }

    const channel = client.channels.cache.get(player.textChannelId);
    if (!channel) return;
    try {
        // Delete previous player message if exists
        if (player.playerMessage) {
            player.playerMessage.delete().catch(() => {});
            player.playerMessage = null;
        }

        // Generate canvas banner
        const bannerBuffer = await generatePlayerBanner(track, player.position, track.info.duration);
        const attachment = new AttachmentBuilder(bannerBuffer, { name: 'player-banner.png' });

        const msg = await channel.send({
            files: [attachment],
            components: [buildPlayerContainer(player)],
            flags: MessageFlags.IsComponentsV2,
        });
        player.playerMessage = msg;

        // ── Set voice channel status ────────────────────────────────────
        await setVoiceStatus(player.voiceChannelId, `<:wavieo_music:1512716593426333837> ${track.info.title}`);

    } catch (err) {
        console.error('[trackStart]', err.message);
    }
});

client.lavalink.on('trackEnd', (player, track) => {
    // handled by autoSkip
});

client.lavalink.on('queueEnd', (player) => {
    // Delete player message
    if (player.playerMessage) {
        player.playerMessage.delete().catch(() => {});
        player.playerMessage = null;
    }
    // Clear voice status
    setVoiceStatus(player.voiceChannelId, '');
    
    const channel = client.channels.cache.get(player.textChannelId);
    const is247 = db247.isEnabled(player.guildId);

    if (is247) {
        if (channel) channel.send(createContainer('📭 Queue finished! 24/7 mode is **enabled**, so I will stay in the channel.')).catch(() => {});
    } else {
        if (channel) channel.send(createContainer('📭 Queue finished! Disconnecting in 30 seconds...')).catch(() => {});
        
        // Start 30s auto-disconnect timeout
        player.emptyTimeout = setTimeout(() => {
            if (!player.queue.current) {
                player.destroy();
                if (channel) channel.send(createContainer('👋 Disconnected due to inactivity.')).catch(() => {});
            }
        }, 30000);
    }
});

client.lavalink.on('trackError', (player, track, payload) => {
    console.error('Track error:', payload?.exception?.message);
    const channel = client.channels.cache.get(player.textChannelId);
    if (channel) channel.send(`<:wavieo_cross:1512706979502755980> Error playing **${track?.info?.title}**: ${payload?.exception?.message}`).catch(() => {});
});

client.lavalink.on('playerDestroy', (player) => {
    if (player.playerMessage) {
        player.playerMessage.delete().catch(() => {});
        player.playerMessage = null;
    }
    // Clear voice status
    setVoiceStatus(player.voiceChannelId, '');
});

// ─── Ready Event ──────────────────────────────────────────────────────────────
client.once('ready', async () => {
    console.log(`<:wavieo_tick:1512706892713955372> Logged in as ${client.user.tag}`);
    // Set the real client ID
    client.lavalink.options.client.id = client.user.id;
    await client.lavalink.init({ id: client.user.id, username: client.user.username });

    // ─── Rotating Activity ────────────────────────────────────────────────────
    const activities = [
        () => ({ name: 'music',                                   type: 2 }), // LISTENING
        () => ({ name: `Serving ${client.guilds.cache.size} servers !`, type: 3 }), // WATCHING
        () => ({ name: '?help for commands',                      type: 0 }), // PLAYING
    ];
    let actIndex = 0;
    const setNextActivity = () => {
        const act = activities[actIndex % activities.length]();
        client.user.setActivity(act.name, { type: act.type });
        actIndex++;
    };
    setNextActivity();
    setInterval(setNextActivity, 5000);
});

// ─── Interaction Handler ─────────────────────────────────────────────────────
client.on('interactionCreate', async (interaction) => {
    const helpCmd = client.commands.get('help');

    // ── Help: category select ────────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'help_category') {
        try {
            await interaction.update({
                components: [helpCmd.buildCategoryContainer(interaction.values[0])],
                flags: MessageFlags.IsComponentsV2,
            });
        } catch (err) { console.error('[help_category]', err.message); }
        return;
    }

    // ── Help: home button ────────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'help_home') {
        try {
            await interaction.update({
                components: [helpCmd.buildHomeContainer(client)],
                flags: MessageFlags.IsComponentsV2,
            });
        } catch (err) { console.error('[help_home]', err.message); }
        return;
    }

    // ── Player buttons & filter ──────────────────────────────────────────────
    const isPlayerBtn    = interaction.isButton()          && interaction.customId.startsWith('player_');
    const isPlayerFilter = interaction.isStringSelectMenu() && interaction.customId === 'player_filter';

    if (!isPlayerBtn && !isPlayerFilter) return;

    const player = client.lavalink.getPlayer(interaction.guild?.id);
    if (!player || !player.queue.current) {
        return interaction.reply(createContainer('<:wavieo_cross:1512706979502755980> No active player.', 0xFF4444, true));
    }

    // Must be in the same voice channel
    const member = interaction.member;
    if (member?.voice?.channelId !== player.voiceChannelId) {
        return interaction.reply(createContainer('<:wavieo_cross:1512706979502755980> Join my voice channel to control playback.', 0xFF4444, true));
    }

    try {
        const id = interaction.customId;

        if (id === 'player_pause') {
            if (player.paused) await player.resume();
            else await player.pause();

        } else if (id === 'player_skip') {
            await player.skip();
            return interaction.reply(createContainer('⏭ Skipped!', 0xFFFFFF, true));

        } else if (id === 'player_stop') {
            await player.destroy();
            return interaction.reply(createContainer('⏹ Stopped!', 0xFFFFFF, true));

        } else if (id === 'player_loop') {
            const next = player.repeatMode === 'none' ? 'track'
                       : player.repeatMode === 'track' ? 'queue' : 'none';
            await player.setRepeatMode(next);

        } else if (id === 'player_shuffle') {
            await player.queue.shuffle();
            return interaction.reply(createContainer('🔀 Queue shuffled!', 0xFFFFFF, true));

        } else if (isPlayerFilter) {
            const filterKey = interaction.values[0];
            const preset    = FILTER_PRESETS[filterKey];
            if (preset) await preset(player.filterManager);
            const filterName = filterKey.charAt(0).toUpperCase() + filterKey.slice(1);
            return interaction.reply(createContainer(`🎛️ Filter set to **${filterName}**`, 0xFFFFFF, true));
        }

        // Update the player message UI
        const track = player.queue.current;
        const bannerBuffer = await generatePlayerBanner(track, player.position, track.info.duration);
        const attachment = new AttachmentBuilder(bannerBuffer, { name: 'player-banner.png' });

        await interaction.update({
            files: [attachment],
            components: [buildPlayerContainer(player)],
            flags: MessageFlags.IsComponentsV2,
        });

    } catch (err) {
        console.error('[player interaction]', err.message);
        if (!interaction.replied && !interaction.deferred)
            interaction.reply({ content: `<:wavieo_cross:1512706979502755980> ${err.message}`, flags: 64 }).catch(() => {});
    }
});

// ─── Message Handler ──────────────────────────────────────────────────────────
const OWNER_ID  = '1490225874585518150';
const npDB      = require('./utils/npDB');
const prefixDB  = require('./utils/prefixDB');
const afkDB     = require('./utils/afk');
const cooldowns = new Collection();

client.on('guildCreate', async (guild) => {
    try {
        const owner = await guild.fetchOwner();
        if (owner) {
            const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
            const container = new ContainerBuilder()
                .setAccentColor(0xFFFFFF)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`🎉 **Thank you for adding me!**\n\nHi **${owner.user.username}**! Thank you so much for adding **Wavieo** to your server, **${guild.name}**!\n\nWe're thrilled to have you. You can start playing music right away by joining a voice channel and typing \`?play <song>\` in any text channel. Type \`?help\` to see all available commands. Enjoy! 🎵`)
                );

            await owner.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    } catch (err) {
        console.error('Failed to send thank you message to guild owner:', err);
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const PREFIX = message.guild ? prefixDB.getPrefix(message.guild.id) : prefixDB.GLOBAL_PREFIX;
    console.log(`[DEBUG] Msg: "${message.content}" | Author: ${message.author.username} (${message.author.id}) | Prefix: "${PREFIX}"`);

    // ── AFK Returning Check ──────────────────────────────────────────────────
    const authorAfk = afkDB.getAFK(message.author.id);
    if (authorAfk && !message.content.toLowerCase().startsWith(`${PREFIX}afk`)) {
        const elapsed = Date.now() - authorAfk.timestamp;
        const timeStr = afkDB.formatDuration(elapsed);
        afkDB.removeAFK(message.author.id);
        message.reply(`<:wavieo_tick:1512706892713955372> welcome back ${message.author} u were away from ${timeStr}`).catch(() => {});
    }

    // ── AFK Mention Checks ───────────────────────────────────────────────────
    if (message.mentions.users.size > 0) {
        message.mentions.users.forEach((user) => {
            if (user.id === message.author.id) return;
            const userAfk = afkDB.getAFK(user.id);
            if (userAfk) {
                const elapsed = Date.now() - userAfk.timestamp;
                const timeStr = afkDB.formatDuration(elapsed);
                message.reply(`<:wavieo_cross:1512706979502755980> **${user.username}** is AFK: ${userAfk.reason} (${timeStr} ago)`).catch(() => {});
            }
        });
    }

    // ── Mention handler ──────────────────────────────────────────────────────
    const exactMentionRegex = new RegExp(`^<@!?${client.user.id}>$`);
    if (exactMentionRegex.test(message.content.trim()) && !message.reference) {
        const mentionCmd = client.commands.get('mention');
        if (mentionCmd) return mentionCmd.execute(message, client);
    }

    // ── Determine effective prefix ───────────────────────────────────────────
    const isOwner   = message.author.id === OWNER_ID;
    const hasNP     = isOwner || npDB.hasAccess(message.author.id);
    const hasPrefix = message.content.startsWith(PREFIX);

    if (!hasPrefix && !hasNP) return;

    // Strip prefix if present, otherwise treat whole message as command
    const content = hasPrefix
        ? message.content.slice(PREFIX.length).trim()
        : message.content.trim();

    if (!content) return;

    const args = content.split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    // ── Cooldown Check ──────────────────────────────────────────────────
    if (message.author.id !== OWNER_ID) {
        const now = Date.now();
        if (!cooldowns.has(command.name)) {
            cooldowns.set(command.name, new Collection());
        }

        const timestamps = cooldowns.get(command.name);
        const cooldownAmount = (command.cooldown || 3) * 1000;

        if (timestamps.has(message.author.id)) {
            const expirationTime = timestamps.get(message.author.id) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
                return message.reply(`⏰ Please wait **${timeLeft}s** before running another command.`)
                    .then(msg => {
                        setTimeout(() => msg.delete().catch(() => {}), 3000);
                    }).catch(() => {});
            }
        }
        timestamps.set(message.author.id, now);
        setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);
    }

    try {
        await command.execute(message, args, client);
    } catch (err) {
        console.error(`Error in command [${commandName}]:`, err);
        message.reply(`<:wavieo_cross:1512706979502755980> Error: ${err.message}`).catch(() => {});
    }
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatDuration(ms) {
    if (!ms) return 'LIVE';
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return hours > 0
        ? `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
        : `${minutes}:${String(seconds).padStart(2, '0')}`;
}

// ─── Global Error Handlers & Client Error Listeners ───────────────────────────
client.on('error', (error) => {
    console.error('⚠️ Discord Client Error:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('⚠️ Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err, origin) => {
    console.error('⚠️ Uncaught Exception:', err, 'origin:', origin);
});

process.on('warning', (warning) => {
    console.warn('⚠️ Process Warning:', warning);
});

// ─── Login ────────────────────────────────────────────────────────────────────
client.login(process.env.DISCORD_TOKEN);
