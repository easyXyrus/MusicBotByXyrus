@echo off
title Wavieo Music Bot
:start
echo [%date% %time%] Starting Wavieo Music Bot...
node index.js
echo.
echo [%date% %time%] Bot process terminated/crashed. Restarting in 5 seconds...
timeout /t 5 >nul
goto start
