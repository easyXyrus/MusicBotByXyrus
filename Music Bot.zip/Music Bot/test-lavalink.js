const http = require('http');

const HOST = 'us.krishna.kajuhost.qzz.io';
const PORT = 19135;
const PASSWORD = 'freelavalinkbykrishna';

function request(path) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: HOST,
            port: PORT,
            path,
            method: 'GET',
            headers: { Authorization: PASSWORD }
        };
        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                console.log(`\n[GET ${path}] Status: ${res.statusCode}`);
                try { console.log(JSON.stringify(JSON.parse(data), null, 2)); }
                catch { console.log(data); }
                resolve({ status: res.statusCode, data });
            });
        });
        req.on('error', reject);
        req.end();
    });
}

(async () => {
    console.log('=== Lavalink Search Test ===');
    const query = encodeURIComponent('ytsearch:never gonna give you up');
    const result = await request(`/v4/loadtracks?identifier=${query}`);
    console.log('\n=== Done ===');
})();
