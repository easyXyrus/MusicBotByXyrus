const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../database/afk.json');

function readDB() {
    try {
        if (!fs.existsSync(DB_PATH)) {
            fs.writeFileSync(DB_PATH, JSON.stringify({}), 'utf8');
        }
        return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    } catch {
        return {};
    }
}

function writeDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

/**
 * Set AFK status for a user.
 * @param {string} userId - The Discord ID of the user.
 * @param {string} reason - The reason for being AFK.
 */
function setAFK(userId, reason) {
    const db = readDB();
    db[userId] = {
        reason: reason || 'I am AFK',
        timestamp: Date.now()
    };
    writeDB(db);
}

/**
 * Get AFK status for a user.
 * @param {string} userId - The Discord ID of the user.
 * @returns {object|null}
 */
function getAFK(userId) {
    const db = readDB();
    return db[userId] || null;
}

/**
 * Remove AFK status for a user.
 * @param {string} userId - The Discord ID of the user.
 * @returns {boolean} - True if user was AFK and removed, false otherwise.
 */
function removeAFK(userId) {
    const db = readDB();
    if (db[userId]) {
        delete db[userId];
        writeDB(db);
        return true;
    }
    return false;
}

/**
 * Formats a duration in milliseconds to a human-readable string.
 * @param {number} ms 
 * @returns {string}
 */
function formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    if (totalSeconds < 1) return 'less than a second';
    
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    const parts = [];
    if (days > 0) parts.push(`${days} day${days > 1 ? 's' : ''}`);
    if (hours > 0) parts.push(`${hours} hour${hours > 1 ? 's' : ''}`);
    if (minutes > 0) parts.push(`${minutes} minute${minutes > 1 ? 's' : ''}`);
    if (seconds > 0) parts.push(`${seconds} second${seconds > 1 ? 's' : ''}`);
    
    if (parts.length === 1) return parts[0];
    if (parts.length === 2) return `${parts[0]} and ${parts[1]}`;
    return `${parts.slice(0, -1).join(', ')}, and ${parts[parts.length - 1]}`;
}

module.exports = {
    setAFK,
    getAFK,
    removeAFK,
    formatDuration
};
