const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');

// Utility to format time
function formatTime(ms) {
    if (!ms) return '0:00';
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
        ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
        : `${m}:${String(sec).padStart(2, '0')}`;
}

// Helper to draw a rounded rectangle
function roundRect(ctx, x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
}

/**
 * Generates the player banner image matching the user's golden theme.
 */
async function generatePlayerBanner(track, pos, dur) {
    const width = 800;
    const height = 250;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // ── Background ─────────────────────────────────────────────────────────────
    // Dark background with slight gradient
    const bgGradient = ctx.createLinearGradient(0, 0, width, height);
    bgGradient.addColorStop(0, '#121212');
    bgGradient.addColorStop(1, '#0a0a0a');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, width, height);

    // Procedural golden dust/particles
    ctx.save();
    for (let i = 0; i < 30; i++) {
        const px = Math.random() * width;
        const py = Math.random() * height;
        const pSize = Math.random() * 3 + 1;
        ctx.beginPath();
        ctx.arc(px, py, pSize, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(247, 213, 88, ${Math.random() * 0.15})`;
        ctx.shadowColor = '#F7D558';
        ctx.shadowBlur = pSize * 3;
        ctx.fill();
    }
    ctx.restore();

    // ── Album Art ──────────────────────────────────────────────────────────────
    const artX = 30;
    const artY = 30;
    const artSize = 140;
    const artRadius = 20;

    // Load album art
    let albumImg;
    try {
        albumImg = await loadImage(track.info.artworkUrl || 'https://i.imgur.com/7nKMpXY.png');
    } catch {
        albumImg = await loadImage('https://i.imgur.com/7nKMpXY.png'); // Fallback
    }

    // Clip and draw image
    ctx.save();
    roundRect(ctx, artX, artY, artSize, artSize, artRadius);
    ctx.clip();
    ctx.drawImage(albumImg, artX, artY, artSize, artSize);
    ctx.restore();

    // Draw Golden Border around Album Art
    ctx.save();
    roundRect(ctx, artX, artY, artSize, artSize, artRadius);
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#F7D558';
    ctx.shadowColor = '#F7D558';
    ctx.shadowBlur = 10;
    ctx.stroke();
    ctx.restore();

    // ── Text: Author & Requester ───────────────────────────────────────────────
    ctx.save();
    const textX = artX + artSize + 30;
    let textY = artY + 50;

    // We use standard sans-serif font
    ctx.font = '22px sans-serif';
    ctx.fillStyle = '#E0E0E0';
    
    ctx.fillText(`Author: ${track.info.author || 'Unknown'}`, textX, textY);
    textY += 35;
    
    let requesterName = 'Unknown';
    if (track.requester) {
        requesterName = track.requester.username || track.requester.tag || track.requester;
    }
    ctx.fillText(`Requested by: ${requesterName}`, textX, textY);
    ctx.restore();

    // ── Progress Bar ───────────────────────────────────────────────────────────
    const barX = textX;
    const barY = artY + artSize - 5;
    const barWidth = width - barX - 50;
    const barHeight = 10;
    const barRadius = 5;

    // Track Progress Calculation
    let progress = 0;
    if (dur > 0) progress = Math.min(pos / dur, 1);

    ctx.save();
    // Background bar (dark golden/grey)
    roundRect(ctx, barX, barY, barWidth, barHeight, barRadius);
    ctx.fillStyle = 'rgba(247, 213, 88, 0.2)';
    ctx.fill();

    // Foreground bar (glowing golden)
    if (progress > 0) {
        roundRect(ctx, barX, barY, Math.max(barWidth * progress, barRadius * 2), barHeight, barRadius);
        ctx.fillStyle = '#F7D558';
        ctx.shadowColor = '#F7D558';
        ctx.shadowBlur = 15;
        ctx.fill();
    }
    ctx.restore();

    // ── Timestamps ─────────────────────────────────────────────────────────────
    ctx.save();
    ctx.font = '16px sans-serif';
    ctx.fillStyle = '#A0A0A0';
    
    // Current Time
    ctx.textAlign = 'left';
    ctx.fillText(formatTime(pos), barX, barY + 25);
    
    // Total Time
    ctx.textAlign = 'right';
    ctx.fillText(formatTime(dur), barX + barWidth, barY + 25);
    ctx.restore();

    return canvas.toBuffer('image/png');
}

module.exports = { generatePlayerBanner };
