const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');

/**
 * Wraps simple text into a Discord Components V2 Container message payload.
 * @param {string} text - The markdown text to display
 * @param {number} color - Hex color for the accent bar
 * @param {boolean} ephemeral - Whether the message should be ephemeral
 * @returns {Object} MessageOptions payload
 */
function createContainer(text, color = 0xFFFFFF, ephemeral = false) {
    const flags = ephemeral 
        ? MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
        : MessageFlags.IsComponentsV2;

    return {
        components: [
            new ContainerBuilder()
                .setAccentColor(color)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`> ${text}`)
                )
        ],
        flags
    };
}

module.exports = { createContainer };
