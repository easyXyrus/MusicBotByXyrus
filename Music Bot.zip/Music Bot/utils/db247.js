const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../database/247.json');

// ─── Read / Write ──────────────────────────────────────────────────────────────
function readDB() {
    try {
        return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    } catch {
        return {};
    }
}

function writeDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

// ─── Public API ───────────────────────────────────────────────────────────────
module.exports = {
    /** Check if 24/7 is enabled for a guild */
    isEnabled(guildId) {
        const db = readDB();
        return !!db[guildId];
    },

    /** Enable 24/7 for a guild */
    enable(guildId) {
        const db = readDB();
        db[guildId] = true;
        writeDB(db);
    },

    /** Disable 24/7 for a guild */
    disable(guildId) {
        const db = readDB();
        delete db[guildId];
        writeDB(db);
    },
};
