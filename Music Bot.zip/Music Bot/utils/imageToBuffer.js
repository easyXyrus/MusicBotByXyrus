const https = require('https');
const http = require('http');
const { URL } = require('url');

/**
 * Basic validation for image URL.
 * @param {string} urlString 
 * @returns {boolean}
 */
function isValidImageUrl(urlString) {
    try {
        const parsed = new URL(urlString);
        if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
        return true;
    } catch {
        return false;
    }
}

/**
 * Fetches an image from a URL and returns its buffer.
 * @param {string} url 
 * @returns {Promise<{buffer: Buffer}>}
 */
async function fetchImageBuffer(url) {
    return new Promise((resolve, reject) => {
        const protocolClient = url.startsWith('https') ? https : http;
        
        protocolClient.get(url, (res) => {
            if (res.statusCode !== 200) {
                reject(new Error(`Status Code: ${res.statusCode}`));
                return;
            }

            const contentType = res.headers['content-type'];
            if (contentType && !contentType.startsWith('image/')) {
                reject(new Error('Content type is not an image'));
                return;
            }

            const chunks = [];
            res.on('data', (chunk) => {
                chunks.push(chunk);
            });

            res.on('end', () => {
                resolve({ buffer: Buffer.concat(chunks) });
            });
        }).on('error', (err) => {
            reject(err);
        });
    });
}

module.exports = {
    isValidImageUrl,
    fetchImageBuffer
};
