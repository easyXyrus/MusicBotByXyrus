const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../database/np.json');

// ─── Read / Write ──────────────────────────────────────────────────────────────
function readDB() {
    try {
        const raw = fs.readFileSync(DB_PATH, 'utf8');
        const data = JSON.parse(raw);
        return data.users || [];
    } catch {
        return [];
    }
}

function writeDB(users) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ users }, null, 2), 'utf8');
}

// ─── Clean expired entries ────────────────────────────────────────────────────
function purgeExpired() {
    const users = readDB();
    const now = Date.now();
    const active = users.filter(u => u.expiresAt === null || u.expiresAt > now);
    if (active.length !== users.length) writeDB(active);
    return active;
}

// ─── Parse duration string → ms ──────────────────────────────────────────────
function parseDuration(str) {
    const match = str.match(/^(\d+)(d|h|m)$/i);
    if (!match) return null;
    const amount = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    if (unit === 'm') return amount * 60 * 1000;
    if (unit === 'h') return amount * 60 * 60 * 1000;
    if (unit === 'd') return amount * 24 * 60 * 60 * 1000;
    return null;
}

// ─── Format ms → human readable ───────────────────────────────────────────────
function formatDuration(ms) {
    if (!ms) return 'Permanent';
    const days    = Math.floor(ms / 86400000);
    const hours   = Math.floor((ms % 86400000) / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    if (days > 0)    return `${days}d ${hours}h`;
    if (hours > 0)   return `${hours}h ${minutes}m`;
    return `${minutes}m`;
}

// ─── Format timestamp → readable ─────────────────────────────────────────────
function formatExpiry(expiresAt) {
    if (!expiresAt) return 'Never';
    const d = new Date(expiresAt);
    return d.toUTCString().replace('GMT', 'UTC');
}

// ─── Public API ───────────────────────────────────────────────────────────────
module.exports = {
    readDB,
    writeDB,
    purgeExpired,
    parseDuration,
    formatDuration,
    formatExpiry,

    addUser(userId, username, addedByTag, durationMs) {
        const users = purgeExpired();
        const existing = users.findIndex(u => u.userId === userId);
        const entry = {
            userId,
            username,
            addedBy: addedByTag,
            addedAt: Date.now(),
            expiresAt: durationMs ? Date.now() + durationMs : null,
            durationLabel: durationMs ? formatDuration(durationMs) : 'Permanent',
        };
        if (existing !== -1) users[existing] = entry;
        else users.push(entry);
        writeDB(users);
        return entry;
    },

    removeUser(userId) {
        const users = readDB();
        const idx = users.findIndex(u => u.userId === userId);
        if (idx === -1) return false;
        users.splice(idx, 1);
        writeDB(users);
        return true;
    },

    getUser(userId) {
        const users = purgeExpired();
        return users.find(u => u.userId === userId) || null;
    },

    listUsers() {
        return purgeExpired();
    },

    hasAccess(userId) {
        const user = module.exports.getUser(userId);
        if (!user) return false;
        if (user.expiresAt === null) return true;
        return user.expiresAt > Date.now();
    },
};
