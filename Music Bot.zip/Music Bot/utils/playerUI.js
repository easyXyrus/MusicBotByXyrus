const {
    ContainerBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    MessageFlags,
} = require('discord.js');

// ─── Filter Definitions ────────────────────────────────────────────────────────
const FILTERS = [
    { label: 'Normal',      value: 'normal',    description: 'Reset all filters',          emoji: '🔄' },
    { label: 'Bass Boost',  value: 'bassboost', description: 'Heavy bass enhancement',     emoji: '🔊' },
    { label: 'Nightcore',   value: 'nightcore', description: 'Sped up + high pitched',     emoji: '🌙' },
    { label: 'Vaporwave',   value: 'vaporwave', description: 'Slowed + low pitched',       emoji: '🌊' },
    { label: 'Karaoke',     value: 'karaoke',   description: 'Vocal removal effect',       emoji: '🎤' },
    { label: '8D Audio',    value: '8d',        description: 'Rotating 8D spatial effect', emoji: '🎧' },
    { label: 'Vibrato',     value: 'vibrato',   description: 'Vibrato pitch wobble',       emoji: '〰️' },
    { label: 'Tremolo',     value: 'tremolo',   description: 'Volume tremolo effect',      emoji: '🎵' },
];

// ─── Filter Presets ────────────────────────────────────────────────────────────
const FILTER_PRESETS = {
    normal:    async (fm) => { await fm.resetFilters(); },
    bassboost: async (fm) => { await fm.setEQPreset('BassboostHigh'); },
    nightcore: async (fm) => { 
        fm.data.timescale = { speed: 1.3, pitch: 1.3, rate: 1.0 }; 
        await fm.applyPlayerFilters(); 
    },
    vaporwave: async (fm) => { 
        fm.data.timescale = { speed: 0.8, pitch: 0.8, rate: 1.0 }; 
        await fm.applyPlayerFilters(); 
    },
    karaoke:   async (fm) => { await fm.toggleKaraoke(1.0, 1.0, 220.0, 100.0); },
    '8d':      async (fm) => { await fm.toggleRotation(0.2); },
    vibrato:   async (fm) => { await fm.toggleVibrato(10, 0.9); },
    tremolo:   async (fm) => { await fm.toggleTremolo(10, 0.9); },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatTime(ms) {
    if (!ms) return '0:00';
    const s   = Math.floor(ms / 1000);
    const h   = Math.floor(s / 3600);
    const m   = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
        ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
        : `${m}:${String(sec).padStart(2, '0')}`;
}

function buildProgressBar(pos, dur, size = 24) {
    if (!dur) return '━'.repeat(size);
    const progress = Math.min(Math.floor((pos / dur) * size), size - 1);
    return '━'.repeat(progress) + '⬤' + '╌'.repeat(size - progress - 1);
}

// ─── Main Player UI Builder ────────────────────────────────────────────────────
function buildPlayerContainer(player) {
    const isPaused = player?.paused;
    const loopMode = player?.repeatMode || 'none';
    const loopIcon = loopMode === 'track' ? '🔂' : loopMode === 'queue' ? '🔁' : '➡️';

    return new ContainerBuilder()
        .setAccentColor(0xFFFFFF)

        // ── Banner Image ───────────────────────────────────────────────────────
        .addMediaGalleryComponents(
            new MediaGalleryBuilder().addItems(
                new MediaGalleryItemBuilder().setURL('attachment://player-banner.png')
            )
        )

        // ── Filter select ──────────────────────────────────────────────────────
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('player_filter')
                    .setPlaceholder('🎛️  Select Filters')
                    .addOptions(
                        FILTERS.map(f =>
                            new StringSelectMenuOptionBuilder()
                                .setLabel(f.label)
                                .setValue(f.value)
                                .setDescription(f.description)
                                .setEmoji(f.emoji)
                        )
                    )
            )
        )

        // ── Control buttons ────────────────────────────────────────────────────
        .addActionRowComponents(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('player_pause')
                    .setLabel(isPaused ? 'Resume' : 'Pause')
                    .setStyle(isPaused ? ButtonStyle.Success : ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('player_skip')
                    .setLabel('Skip')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('player_stop')
                    .setLabel('Stop')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('player_loop')
                    .setLabel('Loop')
                    .setEmoji(loopIcon)
                    .setStyle(loopMode !== 'none' ? ButtonStyle.Primary : ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('player_shuffle')
                    .setLabel('Shuffle')
                    .setStyle(ButtonStyle.Secondary),
            )
        );
}

module.exports = { buildPlayerContainer, FILTERS, FILTER_PRESETS, formatTime };
