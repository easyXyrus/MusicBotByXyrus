const fs   = require('fs');
const path = require('path');

const DB_PATH      = path.join(__dirname, '../database/prefixes.json');
const GLOBAL_PREFIX = '?';

// ─── Read / Write ──────────────────────────────────────────────────────────────
function readDB() {
    try {
        return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    } catch {
        return {};
    }
}

function writeDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

// ─── Public API ───────────────────────────────────────────────────────────────
module.exports = {
    GLOBAL_PREFIX,

    /** Get the prefix for a guild (falls back to global) */
    getPrefix(guildId) {
        const db = readDB();
        return db[guildId] ?? GLOBAL_PREFIX;
    },

    /** Set a custom prefix for a guild */
    setPrefix(guildId, prefix) {
        const db = readDB();
        db[guildId] = prefix;
        writeDB(db);
    },

    /** Reset a guild back to the global prefix */
    resetPrefix(guildId) {
        const db = readDB();
        delete db[guildId];
        writeDB(db);
    },
};
