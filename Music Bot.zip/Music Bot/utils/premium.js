const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../database/premium.json');

function readDB() {
    try {
        if (!fs.existsSync(DB_PATH)) {
            fs.writeFileSync(DB_PATH, JSON.stringify({}), 'utf8');
        }
        return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    } catch {
        return {};
    }
}

function writeDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

/**
 * Checks if a guild has an active premium subscription.
 * @param {string} userId - The user's Discord ID (unused as User Premium was removed).
 * @param {string} guildId - The guild's Discord ID to check.
 * @returns {boolean}
 */
function hasPremium(userId, guildId) {
    if (!guildId) return false;
    const db = readDB();
    const guildData = db[guildId];
    if (!guildData) return false;

    const isPremium = guildData.premium === true && 
        (!guildData.premiumUntil || new Date(guildData.premiumUntil).getTime() > Date.now());

    return isPremium;
}

/**
 * Gets the premium data for a guild.
 * @param {string} guildId 
 * @returns {object|null}
 */
function getPremiumData(guildId) {
    const db = readDB();
    return db[guildId] || null;
}

/**
 * Sets premium status for a guild.
 * @param {string} guildId 
 * @param {boolean} premium 
 * @param {Date|null} premiumUntil 
 */
function setPremium(guildId, premium, premiumUntil = null) {
    const db = readDB();
    
    let isoDate = null;
    if (premiumUntil) {
        const d = new Date(premiumUntil);
        if (!isNaN(d.getTime())) {
            isoDate = d.toISOString();
        }
    }

    db[guildId] = {
        premium,
        premiumUntil: isoDate
    };
    writeDB(db);
}

/**
 * Revokes premium status for a guild.
 * @param {string} guildId 
 */
function revokePremium(guildId) {
    const db = readDB();
    delete db[guildId];
    writeDB(db);
}

module.exports = {
    hasPremium,
    getPremiumData,
    setPremium,
    revokePremium
};
